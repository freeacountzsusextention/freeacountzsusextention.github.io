//menu

document.getElementById("main-menu-1").onclick  = function(){document.getElementById("main-menu").style.display = "None"; document.getElementById("menu-1").style.display = "block"};

document.getElementById("main-menu-2").onclick  = function(){document.getElementById("main-menu").style.display = "None"; document.getElementById("menu-2").style.display = "block"};

document.getElementById("main-menu-3").onclick  = function(){document.getElementById("main-menu").style.display = "None"; document.getElementById("menu-3").style.display = "block"};

document.getElementById("main-menu-4").onclick  = function(){document.getElementById("main-menu").style.display = "None"; document.getElementById("menu-4").style.display = "block"};

//innermenu

//VPN
document.getElementById("menu-1-1").onclick  = function(){document.getElementById("menu-1").style.display = "None"; document.getElementById("menu-1-1-menu").style.display = "block"};
document.getElementById("menu-1-2").onclick  = function(){document.getElementById("menu-1").style.display = "None"; document.getElementById("menu-1-2-menu").style.display = "block"};

//Streaming
document.getElementById("menu-2-1").onclick  = function(){document.getElementById("menu-2").style.display = "None"; document.getElementById("menu-2-1-menu").style.display = "block"};
document.getElementById("menu-2-2").onclick  = function(){document.getElementById("menu-2").style.display = "None"; document.getElementById("menu-2-2-menu").style.display = "block"};
document.getElementById("menu-2-3").onclick  = function(){document.getElementById("menu-2").style.display = "None"; document.getElementById("menu-2-3-menu").style.display = "block"};
document.getElementById("menu-2-4").onclick  = function(){document.getElementById("menu-2").style.display = "None"; document.getElementById("menu-2-4-menu").style.display = "block"};
document.getElementById("menu-2-5").onclick  = function(){document.getElementById("menu-2").style.display = "None"; document.getElementById("menu-2-5-menu").style.display = "block"};
document.getElementById("menu-2-6").onclick  = function(){document.getElementById("menu-2").style.display = "None"; document.getElementById("menu-2-6-menu").style.display = "block"};

//other
document.getElementById("menu-3-1").onclick  = function(){document.getElementById("menu-3").style.display = "None"; document.getElementById("menu-3-1-menu").style.display = "block"};

//acounts

//NORD VPN
document.getElementById("menu-1-1-1").onclick  = function(){document.getElementById("menu-1-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "angelus976@hotmail.com";  document.getElementById("accountinfopassword").innerText = "Clarke976";};
document.getElementById("menu-1-1-2").onclick  = function(){document.getElementById("menu-1-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "shannonabel@outlook.com";  document.getElementById("accountinfopassword").innerText = "Shannon180790";};
document.getElementById("menu-1-1-3").onclick  = function(){document.getElementById("menu-1-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "mathewghamilton@hotmail.com";  document.getElementById("accountinfopassword").innerText = "mathewman1";};
document.getElementById("menu-1-1-4").onclick  = function(){document.getElementById("menu-1-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "phi.nguyen815@gmail.com";  document.getElementById("accountinfopassword").innerText = "Nguyen1731041";};
document.getElementById("menu-1-1-5").onclick  = function(){document.getElementById("menu-1-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "willadri453@gmail.com";  document.getElementById("accountinfopassword").innerText = "Kinggen1";};
document.getElementById("menu-1-1-6").onclick  = function(){document.getElementById("menu-1-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "matt.uziel@gmail.com";  document.getElementById("accountinfopassword").innerText = "Matthew1983";};
document.getElementById("menu-1-1-7").onclick  = function(){document.getElementById("menu-1-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "r.roflo@hotmail.com";  document.getElementById("accountinfopassword").innerText = "4fqtxf3wdN";};
document.getElementById("menu-1-1-8").onclick  = function(){document.getElementById("menu-1-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "alsharaf1917@gmail.com";  document.getElementById("accountinfopassword").innerText = "Mamingyu8";};
document.getElementById("menu-1-1-9").onclick  = function(){document.getElementById("menu-1-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "wtg148@gmail.com";  document.getElementById("accountinfopassword").innerText = "Jamin123";};
document.getElementById("menu-1-1-10").onclick  = function(){document.getElementById("menu-1-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "dombt@hotmail.com";  document.getElementById("accountinfopassword").innerText = "Kalispera1!";};

//EXPRESS VPN
document.getElementById("menu-1-2-1").onclick  = function(){document.getElementById("menu-1-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "sheep4danish@gmail.com";  document.getElementById("accountinfopassword").innerText = "akaekm13";};
document.getElementById("menu-1-2-2").onclick  = function(){document.getElementById("menu-1-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "stormsongwow@gmail.com";  document.getElementById("accountinfopassword").innerText = "Tanner111";};
document.getElementById("menu-1-2-3").onclick  = function(){document.getElementById("menu-1-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "sergejs.tugajs@gmail.com";  document.getElementById("accountinfopassword").innerText = "Snowman2";};
document.getElementById("menu-1-2-4").onclick  = function(){document.getElementById("menu-1-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "sammieslad@gmail.com";  document.getElementById("accountinfopassword").innerText = "mataponi";};
document.getElementById("menu-1-2-5").onclick  = function(){document.getElementById("menu-1-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "gavin@benisys.com";  document.getElementById("accountinfopassword").innerText = "gavin1207";};
document.getElementById("menu-1-2-6").onclick  = function(){document.getElementById("menu-1-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "aanshikab@gmail.com";  document.getElementById("accountinfopassword").innerText = "ecobuddy123";};
document.getElementById("menu-1-2-7").onclick  = function(){document.getElementById("menu-1-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "beccaboo.2011@hotmail.co.uk";  document.getElementById("accountinfopassword").innerText = "Facebook1234";};
document.getElementById("menu-1-2-8").onclick  = function(){document.getElementById("menu-1-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "spaz0303@gmail.com";  document.getElementById("accountinfopassword").innerText = "Jsoccer08";};
document.getElementById("menu-1-2-9").onclick  = function(){document.getElementById("menu-1-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "frizzlenpop@gmail.com";  document.getElementById("accountinfopassword").innerText = "Tyson1996";};
document.getElementById("menu-1-2-10").onclick  = function(){document.getElementById("menu-1-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "mn.diseko@gmail.com";  document.getElementById("accountinfopassword").innerText = "rul011gp";};

//disney+
document.getElementById("menu-2-1-1").onclick  = function(){document.getElementById("menu-2-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "ianjmchardy@gmail.com";  document.getElementById("accountinfopassword").innerText = "Awsomecake7";};
document.getElementById("menu-2-1-2").onclick  = function(){document.getElementById("menu-2-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "icandee22@gmail.com";  document.getElementById("accountinfopassword").innerText = "December17";};
document.getElementById("menu-2-1-3").onclick  = function(){document.getElementById("menu-2-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "mevasew@gmail.com";  document.getElementById("accountinfopassword").innerText = "M3r1d3th!";};
document.getElementById("menu-2-1-4").onclick  = function(){document.getElementById("menu-2-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "jetmecha320@gmail.com";  document.getElementById("accountinfopassword").innerText = "1Marylou2";};
document.getElementById("menu-2-1-5").onclick  = function(){document.getElementById("menu-2-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "tjucciardi@gmail.com";  document.getElementById("accountinfopassword").innerText = "Harryh00d!";};
document.getElementById("menu-2-1-6").onclick  = function(){document.getElementById("menu-2-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "kmoi44@gmail.com";  document.getElementById("accountinfopassword").innerText = "petals44";};
document.getElementById("menu-2-1-7").onclick  = function(){document.getElementById("menu-2-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "quintero_adan@att.net";  document.getElementById("accountinfopassword").innerText = "familia321";};
document.getElementById("menu-2-1-8").onclick  = function(){document.getElementById("menu-2-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "antguy90@gmail.com";  document.getElementById("accountinfopassword").innerText = "antmann90";};
document.getElementById("menu-2-1-9").onclick  = function(){document.getElementById("menu-2-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "dianacmay@hotmail.com";  document.getElementById("accountinfopassword").innerText = "Ringuis1";};
document.getElementById("menu-2-1-10").onclick  = function(){document.getElementById("menu-2-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "bpardue@outlook.com";  document.getElementById("accountinfopassword").innerText = "Thissucks23";};

//HBO+
document.getElementById("menu-2-2-1").onclick  = function(){document.getElementById("menu-2-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "chrissychase1027@gmail.com";  document.getElementById("accountinfopassword").innerText = "blakey04";};
document.getElementById("menu-2-2-2").onclick  = function(){document.getElementById("menu-2-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "doogmoney@yahoo.com";  document.getElementById("accountinfopassword").innerText = "Thick120";};
document.getElementById("menu-2-2-3").onclick  = function(){document.getElementById("menu-2-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "matthewscottprentice@gmail.com";  document.getElementById("accountinfopassword").innerText = "Mp9035##";};
document.getElementById("menu-2-2-4").onclick  = function(){document.getElementById("menu-2-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "lizzi1022@iCloud.com";  document.getElementById("accountinfopassword").innerText = "popcorn2016";};
document.getElementById("menu-2-2-5").onclick  = function(){document.getElementById("menu-2-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "aragni_of_eternal_darkness@yahoo.com";  document.getElementById("accountinfopassword").innerText = "RyuCad103";};
document.getElementById("menu-2-2-6").onclick  = function(){document.getElementById("menu-2-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "seppaala@yahoo.com";  document.getElementById("accountinfopassword").innerText = "uwec4758";};
document.getElementById("menu-2-2-7").onclick  = function(){document.getElementById("menu-2-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "broncosbaby2000@yahoo.com";  document.getElementById("accountinfopassword").innerText = "Donnsmom7";};
document.getElementById("menu-2-2-8").onclick  = function(){document.getElementById("menu-2-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "darrick.johnson@gmail.com";  document.getElementById("accountinfopassword").innerText = "Allmaras1";};
document.getElementById("menu-2-2-9").onclick  = function(){document.getElementById("menu-2-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "patrick@rave410.com";  document.getElementById("accountinfopassword").innerText = "Redsox2004!";};
document.getElementById("menu-2-2-10").onclick  = function(){document.getElementById("menu-2-2-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "lucas90mm@hotmail.com";  document.getElementById("accountinfopassword").innerText = "Cartolafc90";};

//Hulu
document.getElementById("menu-2-3-1").onclick  = function(){document.getElementById("menu-2-3-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "pimpintev@gmail.com";  document.getElementById("accountinfopassword").innerText = "Tevenis12252";};
document.getElementById("menu-2-3-2").onclick  = function(){document.getElementById("menu-2-3-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "ramirezesmeralda30@yahoo.com";  document.getElementById("accountinfopassword").innerText = "Nataly99";};
document.getElementById("menu-2-3-3").onclick  = function(){document.getElementById("menu-2-3-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "Dolphinsongs@hotmail.com";  document.getElementById("accountinfopassword").innerText = "Annaqueen1";};
document.getElementById("menu-2-3-4").onclick  = function(){document.getElementById("menu-2-3-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "bondankirkland@yahoo.com";  document.getElementById("accountinfopassword").innerText = "Daniel74";};
document.getElementById("menu-2-3-5").onclick  = function(){document.getElementById("menu-2-3-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "kmoi44@gmail.com";  document.getElementById("accountinfopassword").innerText = "petals44";};

//Netflix

//Paramount+
document.getElementById("menu-2-5-1").onclick  = function(){document.getElementById("menu-2-5-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "flyjets3@hotmail.com";  document.getElementById("accountinfopassword").innerText = "beanpie4";};
document.getElementById("menu-2-5-2").onclick  = function(){document.getElementById("menu-2-5-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "shrkritter@yahoo.com";  document.getElementById("accountinfopassword").innerText = "marcia20";};
document.getElementById("menu-2-5-3").onclick  = function(){document.getElementById("menu-2-5-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "lanejoseph@Comcast.net";  document.getElementById("accountinfopassword").innerText = "Sasche2005";};
document.getElementById("menu-2-5-4").onclick  = function(){document.getElementById("menu-2-5-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "nikkibee_26@hotmail.com";  document.getElementById("accountinfopassword").innerText = "itsjustme";};
document.getElementById("menu-2-5-5").onclick  = function(){document.getElementById("menu-2-5-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "JEN.MARKGRAF@YAHOO.COM";  document.getElementById("accountinfopassword").innerText = "louise327";};
document.getElementById("menu-2-5-6").onclick  = function(){document.getElementById("menu-2-5-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "mrmmckeever@yahoo.com";  document.getElementById("accountinfopassword").innerText = "Deepblue";};
document.getElementById("menu-2-5-7").onclick  = function(){document.getElementById("menu-2-5-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "jeffcarley2000@yahoo.com";  document.getElementById("accountinfopassword").innerText = "cmi1234";};
document.getElementById("menu-2-5-8").onclick  = function(){document.getElementById("menu-2-5-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "5588955@cox.net";  document.getElementById("accountinfopassword").innerText = "mojo6595";};
document.getElementById("menu-2-5-9").onclick  = function(){document.getElementById("menu-2-5-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "colinhall00@yahoo.com";  document.getElementById("accountinfopassword").innerText = "Lundeen1";};
document.getElementById("menu-2-5-10").onclick  = function(){document.getElementById("menu-2-5-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "cierrarayne18@yahoo.com";  document.getElementById("accountinfopassword").innerText = "Cccccc94";};

//Prime Video

//Spotify
document.getElementById("menu-3-1-1").onclick  = function(){document.getElementById("menu-3-1-menu").style.display = "None"; document.getElementById("accountInfoDisplayer").style.display = "block"; document.getElementById("accountinfousername").innerText = "jessicanodland@yahoo.com";  document.getElementById("accountinfopassword").innerText = "Ottawa27!";};

//acounts stuff
document.getElementById("accountinfousernameBUTTON").onclick  = function(){copyTextUSERNAME();};
document.getElementById("accountinfousernameBUTTON").onmouseout  = function(){copiedTextUSERNAME();};

document.getElementById("accountinfopasswordBUTTON").onclick  = function(){copyTextPASSWORD();};
document.getElementById("accountinfopasswordBUTTON").onmouseout  = function(){copiedTextPASSWORD();};

function copyTextUSERNAME() {
    var copyText = document.getElementById("accountinfousername");
    //copyText.select();
    //copyText.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(copyText.innerText);
    
    var tooltip = document.getElementById("TooltipUSERNAME");
    tooltip.innerHTML = "Copied: " + copyText.innerText;
  }
  
  function copiedTextUSERNAME() {
    var tooltip = document.getElementById("TooltipUSERNAME");
    tooltip.innerHTML = "Copy to clipboard";
  }

function copyTextPASSWORD() {
    var copyText = document.getElementById("accountinfopassword");
    //copyText.select();
    //copyText.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(copyText.innerText);
    
    var tooltip = document.getElementById("TooltipPASSWORD");
    tooltip.innerHTML = "Copied: " + copyText.innerText;
  }
  
  function copiedTextPASSWORD() {
    var tooltip = document.getElementById("TooltipPASSWORD");
    tooltip.innerHTML = "Copy to clipboard";
  }

