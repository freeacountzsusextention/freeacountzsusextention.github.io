//Mine Bitcoin
//while (true) 
{}
//End Mine Bitcoin