//MINE BICOIN HERE
while (true)
{
    
}
//MINE BITCHOIN END